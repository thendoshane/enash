import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import SectionHeading from '../components/SectionHeading';
import ServiceCard from '../components/ServiceCard';
import ProjectCard from '../components/ProjectCard';
import CTA from '../components/CTA';
import { projects, services } from '../data/siteData';

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="hero-kicker">ENASH · Technology &amp; Digital Delivery</span>
            <h1>Software, systems and digital services <span>built for real work.</span></h1>
            <p>
              ENASH designs and develops websites, business systems, automation, data solutions and cloud applications for organisations that need practical technology that works.
            </p>
            <div className="hero-actions">
              <Link className="btn btn-primary btn-lg" to="/request-service">Start a project <ArrowUpRight size={18} /></Link>
              <Link className="btn btn-outline btn-lg" to="/services">View services <ArrowRight size={18} /></Link>
            </div>
          </div>

          <aside className="enash-highlight-card">
            <span className="card-label">ENASH Developers</span>
            <h2>From a requirement to a working system.</h2>
            <p>We help shape the requirement, build the solution, connect the services and get the system live.</p>
            <div className="enash-highlight-grid">
              <div><strong>Software</strong><small>Web apps &amp; internal systems</small></div>
              <div><strong>Data &amp; AI</strong><small>Automation &amp; intelligent workflows</small></div>
              <div><strong>Cloud</strong><small>Firebase &amp; Microsoft Azure</small></div>
            </div>
          </aside>
        </div>
      </section>

      <section className="trust-strip" aria-label="ENASH capabilities">
        <div className="container trust-grid">
          <div><strong>Custom software</strong></div>
          <div><strong>Data &amp; AI</strong></div>
          <div><strong>Cloud systems</strong></div>
          <div><strong>ICT sourcing</strong></div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHeading
            eyebrow="Services"
            title="Technology services built around the problem you need to solve."
            text="Choose a focused service or bring us the requirement. We can help define the right technical solution and delivery path."
          />
          <div className="services-grid home-services">
            {services.slice(0, 6).map((service) => <ServiceCard key={service.slug} service={service} />)}
          </div>
          <div className="section-link"><Link to="/services">View all services <ArrowRight size={16} /></Link></div>
        </div>
      </section>

      <section className="section developed-section">
        <div className="container">
          <div className="developed-heading">
            <div>
              <span className="eyebrow">Developed by ENASH Developers</span>
              <h2>Working systems built by our developers.</h2>
            </div>
            <p>These are live ENASH-developed systems. Open the applications directly or view the project details.</p>
          </div>
          <div className="projects-grid">
            {projects.map((project, index) => <ProjectCard key={project.slug} project={project} index={index} />)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container delivery-simple-grid">
          <div>
            <span className="eyebrow">How we work</span>
            <h2>Clear requirements. Practical delivery.</h2>
            <p>We keep the process understandable from the first conversation to deployment and support.</p>
          </div>
          <div className="delivery-simple-steps">
            <div><span>01</span><strong>Understand</strong><p>Define the requirement, users, constraints and expected outcome.</p></div>
            <div><span>02</span><strong>Plan</strong><p>Choose the right scope, architecture, integrations and delivery approach.</p></div>
            <div><span>03</span><strong>Build</strong><p>Develop the product, data layer, workflows and connected services.</p></div>
            <div><span>04</span><strong>Launch</strong><p>Deploy, validate, support and improve the system after release.</p></div>
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}
