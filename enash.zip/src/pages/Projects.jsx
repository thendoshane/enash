import PageHero from '../components/PageHero';
import ProjectCard from '../components/ProjectCard';
import CTA from '../components/CTA';
import { projects } from '../data/siteData';

export default function Projects() {
  return (
    <>
      <PageHero
        eyebrow="Developed Systems"
        title="Working systems developed by ENASH Developers."
        text="Open the live ENASH systems below or view their project details to see the type of software our developers build."
      />

      <section className="section developed-section project-page-section">
        <div className="container projects-grid">
          {projects.map((project, index) => <ProjectCard key={project.slug} project={project} index={index} />)}
        </div>
      </section>

      <section className="section">
        <div className="container portfolio-note">
          <span className="eyebrow">ENASH Developers</span>
          <h2>Different business problems. Practical digital systems.</h2>
          <p>ENASH develops systems across operations, mobility, business workflows and customer-facing digital services. Each project starts with a real requirement and is shaped around the people who will use it.</p>
        </div>
      </section>

      <CTA title="Need a system built for your business?" text="Send the requirement and ENASH will help shape the next practical step." />
    </>
  );
}
